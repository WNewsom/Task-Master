package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;



import javafx.event.ActionEvent;


import java.io.IOException;
import javafx.fxml.FXML;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller {

    ObservableList<Task> obsTask  = FXCollections.observableArrayList(Task.extractor);


    @FXML private Button newTaskButton;

    @FXML private Button retButton;

    @FXML private Button saveButton;

    @FXML private Button editButton;// = new Button();

    @FXML private Button completeButton;// = new Button();

    @FXML private ListView<Task> taskView;// = new ListView<Task>();

    @FXML private TextField nameBox;// = new TextField();

    @FXML private TextArea descBox;// = new TextArea();

    @FXML private TextField hoursBox;// = new TextField();

    @FXML private TextField minBox;// = new TextField();

    @FXML private ComboBox<String> apBox = new ComboBox<String>();

    @FXML private MenuBar menuBar;

    @FXML private MenuItem newTaskItem;// = new MenuItem();

    @FXML private Menu editMenu;

    @FXML private MenuItem editItem;// = new MenuItem();

    @FXML private MenuItem deleteItem;// = new MenuItem();




    @FXML
    public void initialize() {


        editButton.disableProperty().bind(taskView.getSelectionModel().selectedItemProperty().isNull());
        completeButton.disableProperty().bind(taskView.getSelectionModel().selectedItemProperty().isNull());
        String amOrPm[] = {"AM", "PM"};

        apBox.setItems(FXCollections.observableArrayList(amOrPm));
        obsTask = FileOperations.readFile();
        taskView.setItems(obsTask);



    }

    @FXML void newTaskButtonAction (ActionEvent event) throws IOException{

        changeScene("editTaskView.fxml");


    }

    @FXML void retButtonAction (ActionEvent event) throws IOException{

        changeScene("sample.fxml");

    }

    @FXML void saveButtonAction (ActionEvent event) throws IOException {
        if (validFields() == false){
            //TODO create popup
            System.out.println("Inputs not valid.");
            return;
        }
        Task t = new Task();
        t.setName(nameBox.getText());
        t.setHour(Integer.parseInt(hoursBox.getText()));
        String s = "0";
        //number is between 0 and 9 with out the leading zero
        if(minBox.getText().length() == 1){
           s = s.concat(minBox.getText());
           t.setMin(s);
        } else{
            t.setMin(minBox.getText());
        }

        t.setAmpm(apBox.getValue());
        t.setDesc(descBox.getText());

        obsTask.add(t);
        for(int i = 0; i < obsTask.size(); i++){
            System.out.println(obsTask.get(i).toString());

        }
        FileOperations.writeToFile(obsTask);
        //TODO Write to file

        changeScene("sample.fxml");


    }

    @FXML
    void completeButtonAction(ActionEvent event) {

    }

    private boolean validFields(){
        if((nameBox.getText().contains("~") == false) && (nameBox.getText() != null)){
            try {
                int n = Integer.parseInt(hoursBox.getText());

                if(n < 0 || n > 13){
                    return false;
                }

            } catch (NumberFormatException e){
                return false;
            }

            try {
                int p = Integer.parseInt(minBox.getText());

                if(p < 0 || p > 59){
                    return false;
                }

            } catch (NumberFormatException e){
                return false;
            }
            if(apBox.getValue() != null){
                return true;
            }

        }
        return false;
    }

    @FXML void editButtonAction(ActionEvent e) throws IOException {
        Task sel = taskView.getSelectionModel().getSelectedItem();
        changeScene("editTaskView.fxml");

        System.out.println(sel.toString());
        nameBox.setText("sel.getName()");
        hoursBox.setText(Integer.toString(sel.getHour()));
        minBox.setText(sel.getMin());
        apBox.getSelectionModel().select(sel.getAmpm());
        descBox.setText(sel.getDesc());

    }

    /**
     * Changes the current scene
     * @param fxml Location of the FMXL File
     * @throws IOException
     */
    private void changeScene(String fxml) throws IOException {
        //This is a poor implementation, but the one we had before it was even worse, so its a slight improvement.
        Parent p = FXMLLoader.load(getClass().getResource(fxml));
        Main.getStage().getScene().setRoot(p);

    }



}
